# odoo_endpoint
A PIP package for odoo endpoints
